# EAORCS Cryptographic Verification Instructions

1. Retrieve public_key.pem, governance_seal_signature.json, artifact_signatures.json, and RELEASE_CERTIFICATE.json from 07_signatures.zip
2. Verify payload and artifact signatures using Ed25519 algorithm against public_key.pem
3. Check artifact SHA-256 hashes against SHA256SUMS and MANIFEST.json in the release bundle directory.
